#!/usr/bin/env bash

## Run this script from the main folder of the workshop materials.

# Create a virtual enviroment for the workshop and activate it
python3.13 -m venv workshop
source workshop/bin/activate

# Install the dependencies
pip install -r requirements.txt

# Download portable blender 

URL="https://mirrors.dotsrc.org/blender/release/Blender5.1/blender-5.1.0-linux-x64.tar.xz"
OUTPUT="blender-5.1.0-linux-x64.tar.xz"
 
echo "Downloading Blender 5.1.0..."
 
if command -v curl &>/dev/null; then
    curl -L --progress-bar -o "$OUTPUT" "$URL"
elif command -v wget &>/dev/null; then
    wget --show-progress -O "$OUTPUT" "$URL"
else
    echo "Error: neither curl nor wget is installed." >&2
    exit 1
fi
 
echo "Done! Saved as: $OUTPUT"

tar -xf $OUTPUT


